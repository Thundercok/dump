using BenThanhTVM.Data;
using BenThanhTVM.Models;
using Microsoft.EntityFrameworkCore;

namespace BenThanhTVM.Services
{
    public class TicketService
    {
        private readonly TvmDbContext _db;
        private static int _ticketCounter = 5;

        public TicketService(TvmDbContext db) => _db = db;

        public async Task<List<Station>> GetStationsAsync(string? lineCode = null)
        {
            var q = _db.Stations.Where(s => s.IsActive);
            if (lineCode != null) q = q.Where(s => s.LineCode == lineCode);
            return await q.OrderBy(s => s.Id).ToListAsync();
        }

        public async Task<decimal> GetFareAsync(int fromZone, int toZone)
        {
            int lo = Math.Min(fromZone, toZone);
            int hi = Math.Max(fromZone, toZone);
            var rule = await _db.FareRules.FirstOrDefaultAsync(r => r.FromZone == lo && r.ToZone == hi);
            return rule?.Fare ?? 6000;
        }

        public async Task<Ticket> CreateTicketAsync(int fromStationId, int toStationId, string paymentMethod)
        {
            var from = await _db.Stations.FindAsync(fromStationId) ?? throw new Exception("Invalid station");
            var to   = await _db.Stations.FindAsync(toStationId)   ?? throw new Exception("Invalid station");
            var fare = await GetFareAsync(from.ZoneNumber, to.ZoneNumber);

            var ticket = new Ticket
            {
                TicketId      = $"TKT-{DateTime.Now:yyyyMMdd}-{Interlocked.Increment(ref _ticketCounter):D4}",
                FromStationId = fromStationId,
                ToStationId   = toStationId,
                Fare          = fare,
                PaymentMethod = paymentMethod,
                Status        = "Pending",
                IssuedAt      = DateTime.Now,
                ValidUntil    = DateTime.Now.AddMinutes(90),
                BarcodeData   = $"HCMC-METRO-{Guid.NewGuid():N}",
                SessionToken  = Guid.NewGuid().ToString("N"),
                MachineId     = "TVM-BT-001"
            };

            _db.Tickets.Add(ticket);
            await _db.SaveChangesAsync();
            return ticket;
        }

        public async Task<PaymentResultViewModel> ProcessPaymentAsync(int ticketDbId, bool simulateSuccess = true)
        {
            var ticket = await _db.Tickets
                .Include(t => t.FromStation)
                .Include(t => t.ToStation)
                .FirstOrDefaultAsync(t => t.Id == ticketDbId);

            if (ticket == null)
                return new PaymentResultViewModel { Success = false, ErrorMessage = "Ticket not found" };

            if (!simulateSuccess)
            {
                ticket.Status = "Cancelled";
                await _db.SaveChangesAsync();
                return new PaymentResultViewModel { Success = false, ErrorMessage = "Payment gateway declined the transaction." };
            }

            ticket.Status        = "Paid";
            ticket.TransactionId = $"TXN-{Guid.NewGuid():N}".ToUpper()[..20];
            await _db.SaveChangesAsync();

            _db.TransactionLogs.Add(new TransactionLog
            {
                TicketId      = ticket.TicketId,
                Amount        = ticket.Fare,
                PaymentMethod = ticket.PaymentMethod,
                Status        = "Paid",
                Timestamp     = DateTime.Now,
                MachineId     = ticket.MachineId
            });
            await _db.SaveChangesAsync();

            return new PaymentResultViewModel
            {
                Success       = true,
                TicketId      = ticket.TicketId,
                TransactionId = ticket.TransactionId ?? "",
                FromStation   = ticket.FromStation?.Name ?? "",
                ToStation     = ticket.ToStation?.Name ?? "",
                Fare          = ticket.Fare,
                PaymentMethod = ticket.PaymentMethod,
                IssuedAt      = ticket.IssuedAt,
                ValidUntil    = ticket.ValidUntil,
                BarcodeData   = ticket.BarcodeData
            };
        }

        public async Task<ReportViewModel> GetDailyReportAsync(DateTime date)
        {
            var start = date.Date;
            var end   = start.AddDays(1);
            var logs  = await _db.TransactionLogs
                .Where(l => l.Timestamp >= start && l.Timestamp < end)
                .OrderByDescending(l => l.Timestamp)
                .ToListAsync();

            return new ReportViewModel
            {
                Transactions            = logs,
                TotalRevenue            = logs.Where(l => l.Status == "Paid").Sum(l => l.Amount),
                TotalTickets            = logs.Count(l => l.Status == "Paid"),
                Date                    = date,
                PaymentMethodBreakdown  = logs.GroupBy(l => l.PaymentMethod)
                                              .ToDictionary(g => g.Key, g => g.Count())
            };
        }
    }
}
