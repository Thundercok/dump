using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BenThanhTVM.Models
{
    // ─── Entities ────────────────────────────────────────────────────────────────

    public class Station
    {
        public int Id { get; set; }
        [Required] public string Name { get; set; } = "";
        public string NameEn { get; set; } = "";
        public int ZoneNumber { get; set; }
        public string LineCode { get; set; } = "MRT1"; // MRT1, BUS, etc.
        public bool IsActive { get; set; } = true;
    }

    public class FareRule
    {
        public int Id { get; set; }
        public int FromZone { get; set; }
        public int ToZone { get; set; }
        public decimal Fare { get; set; }           // VND
    }

    public class Ticket
    {
        public int Id { get; set; }
        [Required] public string TicketId { get; set; } = "";       // e.g. TKT-20250406-0001
        public int FromStationId { get; set; }
        public int ToStationId { get; set; }
        public Station? FromStation { get; set; }
        public Station? ToStation { get; set; }
        public decimal Fare { get; set; }
        public string PaymentMethod { get; set; } = "";             // CreditCard | MoMo | VNPay | ZaloPay
        public string Status { get; set; } = "Pending";             // Pending | Paid | Cancelled
        public DateTime IssuedAt { get; set; } = DateTime.Now;
        public DateTime ValidUntil { get; set; }
        public string BarcodeData { get; set; } = "";
        public string? TransactionId { get; set; }
        public string MachineId { get; set; } = "TVM-BT-001";
        public string SessionToken { get; set; } = "";
    }

    public class TransactionLog
    {
        public int Id { get; set; }
        public string TicketId { get; set; } = "";
        public decimal Amount { get; set; }
        public string PaymentMethod { get; set; } = "";
        public string Status { get; set; } = "";
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public string MachineId { get; set; } = "TVM-BT-001";
        public string? Notes { get; set; }
    }

    // ─── View Models ─────────────────────────────────────────────────────────────

    public class HomeViewModel
    {
        public string MachineId { get; set; } = "TVM-BT-001";
        public string CurrentStation { get; set; } = "Bến Thành";
        public bool IsOnline { get; set; } = true;
        public DateTime CurrentTime { get; set; } = DateTime.Now;
    }

    public class BuyTicketViewModel
    {
        public List<Station> Stations { get; set; } = new();
        public int? SelectedStationId { get; set; }
        public string TransportType { get; set; } = "MRT";
        public decimal Fare { get; set; }
        public string PaymentMethod { get; set; } = "";
    }

    public class PaymentViewModel
    {
        public int TicketId { get; set; }
        public string TicketCode { get; set; } = "";
        public string FromStation { get; set; } = "";
        public string ToStation { get; set; } = "";
        public decimal Fare { get; set; }
        public string PaymentMethod { get; set; } = "";
        public string? QrCodeBase64 { get; set; }
        public string SessionToken { get; set; } = "";
        public int TimeoutSeconds { get; set; } = 180;
    }

    public class PaymentResultViewModel
    {
        public bool Success { get; set; }
        public string TicketId { get; set; } = "";
        public string TransactionId { get; set; } = "";
        public string FromStation { get; set; } = "";
        public string ToStation { get; set; } = "";
        public decimal Fare { get; set; }
        public string PaymentMethod { get; set; } = "";
        public DateTime IssuedAt { get; set; }
        public DateTime ValidUntil { get; set; }
        public string BarcodeData { get; set; } = "";
        public string? ErrorMessage { get; set; }
    }

    public class ReportViewModel
    {
        public List<TransactionLog> Transactions { get; set; } = new();
        public decimal TotalRevenue { get; set; }
        public int TotalTickets { get; set; }
        public DateTime Date { get; set; } = DateTime.Today;
        public Dictionary<string, int> PaymentMethodBreakdown { get; set; } = new();
    }
}
