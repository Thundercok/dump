using Microsoft.AspNetCore.Mvc;
using BenThanhTVM.Models;
using BenThanhTVM.Services;

namespace BenThanhTVM.Controllers
{
    public class HomeController : Controller
    {
        private readonly TicketService _svc;
        public HomeController(TicketService svc) => _svc = svc;

        public IActionResult Index()
        {
            var vm = new HomeViewModel
            {
                MachineId      = "TVM-BT-001",
                CurrentStation = "Bến Thành",
                IsOnline       = true,
                CurrentTime    = DateTime.Now
            };
            return View(vm);
        }

        public IActionResult Error520() => View("Error520");
        public IActionResult Error5()   => View("Error5");
        public IActionResult Error408() => View("Error408");
    }
}
