using Microsoft.AspNetCore.Mvc;
using BenThanhTVM.Models;
using BenThanhTVM.Services;

namespace BenThanhTVM.Controllers
{
    public class TicketController : Controller
    {
        private readonly TicketService _svc;
        public TicketController(TicketService svc) => _svc = svc;

        // GET /Ticket/Buy
        [HttpGet]
        public async Task<IActionResult> Buy()
        {
            var vm = new BuyTicketViewModel
            {
                Stations      = await _svc.GetStationsAsync("MRT1"),
                TransportType = "MRT"
            };
            return View(vm);
        }

        // GET /Ticket/GetFare?fromId=1&toId=5
        [HttpGet]
        public async Task<IActionResult> GetFare(int fromId, int toId)
        {
            var stations = await _svc.GetStationsAsync();
            var from = stations.FirstOrDefault(s => s.Id == fromId);
            var to   = stations.FirstOrDefault(s => s.Id == toId);
            if (from == null || to == null) return Json(new { fare = 0 });
            var fare = await _svc.GetFareAsync(from.ZoneNumber, to.ZoneNumber);
            return Json(new { fare, fareFormatted = $"{fare:#,##0} đ" });
        }

        // POST /Ticket/SelectPayment
        [HttpPost]
        public async Task<IActionResult> SelectPayment(int toStationId, string paymentMethod)
        {
            // Origin is always BenThanh (id=1) for this machine
            var ticket = await _svc.CreateTicketAsync(1, toStationId, paymentMethod);

            if (paymentMethod == "CreditCard")
            {
                var vm = new PaymentViewModel
                {
                    TicketId      = ticket.Id,
                    TicketCode    = ticket.TicketId,
                    FromStation   = "Bến Thành",
                    ToStation     = (await _svc.GetStationsAsync()).FirstOrDefault(s => s.Id == toStationId)?.Name ?? "",
                    Fare          = ticket.Fare,
                    PaymentMethod = "CreditCard",
                    SessionToken  = ticket.SessionToken,
                    TimeoutSeconds = 180
                };
                return View("PayByCreditCard", vm);
            }
            else
            {
                // QR Payment (MoMo / VNPay / ZaloPay)
                var qrData = $"https://pay.momo.vn/qr/{ticket.TicketId}?amount={ticket.Fare}";
                var vm = new PaymentViewModel
                {
                    TicketId      = ticket.Id,
                    TicketCode    = ticket.TicketId,
                    FromStation   = "Bến Thành",
                    ToStation     = (await _svc.GetStationsAsync()).FirstOrDefault(s => s.Id == toStationId)?.Name ?? "",
                    Fare          = ticket.Fare,
                    PaymentMethod = paymentMethod,
                    QrCodeBase64  = GenerateSvgQr(qrData),
                    SessionToken  = ticket.SessionToken,
                    TimeoutSeconds = 180
                };
                return View("PayByQR", vm);
            }
        }

        // POST /Ticket/ConfirmPayment
        [HttpPost]
        public async Task<IActionResult> ConfirmPayment(int ticketId, bool simulateSuccess = true)
        {
            var result = await _svc.ProcessPaymentAsync(ticketId, simulateSuccess);
            if (result.Success)
                return View("PaymentSuccess", result);
            return View("PaymentFail", result);
        }

        // POST /Ticket/QRPay  (kiosk tap NFC/QR reader)
        [HttpGet]
        public IActionResult QRPay(int ticketId, string method)
        {
            return View("QRPayKiosk", new { TicketId = ticketId, Method = method });
        }

        // GET /Ticket/Report
        [HttpGet]
        public async Task<IActionResult> Report(DateTime? date)
        {
            var vm = await _svc.GetDailyReportAsync(date ?? DateTime.Today);
            return View(vm);
        }

        // ── Helper ─────────────────────────────────────────────────────────────
        private static string GenerateSvgQr(string data)
        {
            // Simple deterministic "fake" QR pattern for demo (no external lib needed)
            var hash = data.GetHashCode();
            var rng  = new Random(hash);
            var sb   = new System.Text.StringBuilder();
            sb.Append("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 210 210'>");
            sb.Append("<rect width='210' height='210' fill='white'/>");
            // Finder patterns
            DrawFinder(sb, 10, 10); DrawFinder(sb, 150, 10); DrawFinder(sb, 10, 150);
            // Data modules
            for (int r = 0; r < 21; r++)
                for (int c = 0; c < 21; c++)
                {
                    bool skip = (r < 8 && c < 8) || (r < 8 && c > 12) || (r > 12 && c < 8);
                    if (!skip && rng.Next(2) == 1)
                        sb.Append($"<rect x='{10 + c * 9}' y='{10 + r * 9}' width='8' height='8' fill='black'/>");
                }
            sb.Append("</svg>");
            return "data:image/svg+xml;base64," + Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(sb.ToString()));
        }

        private static void DrawFinder(System.Text.StringBuilder sb, int x, int y)
        {
            sb.Append($"<rect x='{x}' y='{y}' width='50' height='50' fill='black'/>");
            sb.Append($"<rect x='{x+8}' y='{y+8}' width='34' height='34' fill='white'/>");
            sb.Append($"<rect x='{x+16}' y='{y+16}' width='18' height='18' fill='black'/>");
        }
    }
}
