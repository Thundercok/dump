using BenThanhTVM.Data;
using BenThanhTVM.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// ── Services ──────────────────────────────────────────────────────────────────

builder.Services.AddControllersWithViews();

// Use InMemory DB for demo; swap to UseSqlServer() for production
builder.Services.AddDbContext<TvmDbContext>(opt =>
    opt.UseInMemoryDatabase("TvmDb"));

builder.Services.AddScoped<TicketService>();

// ── App ───────────────────────────────────────────────────────────────────────

var app = builder.Build();

// Seed the in-memory database
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<TvmDbContext>();
    db.Database.EnsureCreated();
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error520");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
