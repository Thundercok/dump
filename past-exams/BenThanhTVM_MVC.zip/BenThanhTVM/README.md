# 🚇 BenThanh Metro – Ticket Vendor Machine (TVM)
## ASP.NET Core 8 MVC + EF Core + MSSQL

---

## 📋 Yêu cầu hệ thống

| Tool              | Version   |
|-------------------|-----------|
| .NET SDK          | 8.0+      |
| Visual Studio     | 2022+     |
| SQL Server        | 2019+ hoặc LocalDB |
| EF Core Tools     | 8.0+      |

---

## 🚀 Cách chạy (InMemory – không cần SQL Server)

```bash
cd BenThanhTVM
dotnet restore
dotnet run
```
Mở trình duyệt: `https://localhost:5001`

---

## 🗄 Cách chạy với MSSQL (Code-First)

### Bước 1 – Cấu hình connection string
Chỉnh `appsettings.json`:
```json
"ConnectionStrings": {
  "DefaultConnection": "Server=.;Database=BenThanhTvmDb;Trusted_Connection=True;"
}
```

### Bước 2 – Đổi sang SQL Server trong Program.cs
Thay dòng:
```csharp
opt.UseInMemoryDatabase("TvmDb")
```
thành:
```csharp
opt.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
```

### Bước 3 – Migrations & tạo DB
```bash
dotnet ef migrations add InitialCreate
dotnet ef database update
```

### Bước 4 – (Tuỳ chọn) Chạy SQL script thủ công
```sql
-- Mở SQL Server Management Studio, chạy file:
Database/init_db.sql
```

---

## 📂 Cấu trúc project

```
BenThanhTVM/
├── Controllers/
│   ├── HomeController.cs       ← Trang chủ, error pages
│   └── TicketController.cs     ← Luồng mua vé, thanh toán
├── Data/
│   └── TvmDbContext.cs         ← EF Core DbContext + seed data
├── Database/
│   └── init_db.sql             ← SQL script khởi tạo MSSQL
├── Models/
│   └── TvmModels.cs            ← Entities + ViewModels
├── Services/
│   └── TicketService.cs        ← Business logic
├── Views/
│   ├── Home/
│   │   ├── Index.cshtml        ← Màn hình chủ (bản đồ metro)
│   │   ├── Error520.cshtml     ← Lỗi hệ thống
│   │   ├── Error5.cshtml       ← Lỗi tải trang
│   │   └── Error408.cshtml     ← Hết phiên / timeout
│   ├── Ticket/
│   │   ├── Buy.cshtml          ← Chọn điểm đến + thanh toán
│   │   ├── PayByQR.cshtml      ← Thanh toán QR (MoMo/VNPay/ZaloPay)
│   │   ├── PayByCreditCard.cshtml ← Thanh toán thẻ tín dụng
│   │   ├── PaymentSuccess.cshtml  ← Vé thành công + barcode
│   │   ├── PaymentFail.cshtml     ← Thất bại / retry
│   │   └── Report.cshtml          ← Báo cáo doanh thu
│   └── Shared/
│       └── _Layout.cshtml      ← Layout chung (Phone UI shell)
├── appsettings.json
├── Program.cs
└── BenThanhTVM.csproj
```

---

## 🔄 Luồng nghiệp vụ

```
[Trang chủ] → [Chọn điểm đến] → [Xem giá vé]
    → [Chọn phương thức] 
        → Credit Card → [Nhập thẻ] → [Xử lý] → [In vé]
        → MoMo/VNPay/ZaloPay → [Hiển thị QR] → [Quét QR] → [In vé]
    → [Thất bại] → [Thử lại / Về trang chủ]
```

---

## 🎭 Demo trong ứng dụng

Vì đây là demo học thuật, hai nút được thêm vào để mô phỏng:
- ✅ **"Mô phỏng thanh toán thành công"** – In vé, lưu log
- ❌ **"Mô phỏng thanh toán thất bại"** – Hiện màn hình lỗi

---

## 👥 Thành viên nhóm

| MSSV       | Họ tên          | Vai trò                        |
|------------|-----------------|-------------------------------|
| 523c0012   | Huỳnh Nhật Huy  | Lead Dev, UI/UX                |
| 523v0002   | Bùi Quang Huy   | System Architect, UML, QA      |

**Trường:** Đại học Tôn Đức Thắng  
**Môn:** Software Engineering – QT2 Assignment 1 – HK2/2025  
**GVHD:** Phạm Thái Ký Trung
