-- ============================================================
-- BenThanh Metro TVM – MSSQL Database Script
-- Run this after: dotnet ef migrations add Init && dotnet ef database update
-- Or execute manually against your SQL Server instance
-- ============================================================

USE master;
GO

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'BenThanhTvmDb')
BEGIN
    CREATE DATABASE BenThanhTvmDb;
END
GO

USE BenThanhTvmDb;
GO

-- ── Stations ─────────────────────────────────────────────────────────────────
IF OBJECT_ID('dbo.Stations', 'U') IS NULL
CREATE TABLE dbo.Stations (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    Name        NVARCHAR(100)  NOT NULL,
    NameEn      NVARCHAR(100)  NOT NULL DEFAULT '',
    ZoneNumber  INT            NOT NULL DEFAULT 1,
    LineCode    NVARCHAR(20)   NOT NULL DEFAULT 'MRT1',
    IsActive    BIT            NOT NULL DEFAULT 1
);
GO

-- ── FareRules ─────────────────────────────────────────────────────────────────
IF OBJECT_ID('dbo.FareRules', 'U') IS NULL
CREATE TABLE dbo.FareRules (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    FromZone    INT            NOT NULL,
    ToZone      INT            NOT NULL,
    Fare        DECIMAL(18,2)  NOT NULL
);
GO

-- ── Tickets ──────────────────────────────────────────────────────────────────
IF OBJECT_ID('dbo.Tickets', 'U') IS NULL
CREATE TABLE dbo.Tickets (
    Id              INT IDENTITY(1,1) PRIMARY KEY,
    TicketId        NVARCHAR(50)   NOT NULL UNIQUE,
    FromStationId   INT            NOT NULL REFERENCES dbo.Stations(Id),
    ToStationId     INT            NOT NULL REFERENCES dbo.Stations(Id),
    Fare            DECIMAL(18,2)  NOT NULL,
    PaymentMethod   NVARCHAR(50)   NOT NULL,
    [Status]        NVARCHAR(20)   NOT NULL DEFAULT 'Pending',
    IssuedAt        DATETIME2      NOT NULL DEFAULT GETDATE(),
    ValidUntil      DATETIME2      NOT NULL,
    BarcodeData     NVARCHAR(200)  NOT NULL DEFAULT '',
    TransactionId   NVARCHAR(100)  NULL,
    MachineId       NVARCHAR(50)   NOT NULL DEFAULT 'TVM-BT-001',
    SessionToken    NVARCHAR(100)  NOT NULL DEFAULT ''
);
GO

-- ── TransactionLogs ──────────────────────────────────────────────────────────
IF OBJECT_ID('dbo.TransactionLogs', 'U') IS NULL
CREATE TABLE dbo.TransactionLogs (
    Id              INT IDENTITY(1,1) PRIMARY KEY,
    TicketId        NVARCHAR(50)   NOT NULL,
    Amount          DECIMAL(18,2)  NOT NULL,
    PaymentMethod   NVARCHAR(50)   NOT NULL,
    [Status]        NVARCHAR(20)   NOT NULL,
    [Timestamp]     DATETIME2      NOT NULL DEFAULT GETDATE(),
    MachineId       NVARCHAR(50)   NOT NULL DEFAULT 'TVM-BT-001',
    Notes           NVARCHAR(500)  NULL
);
GO

-- ── Seed: Stations ────────────────────────────────────────────────────────────
DELETE FROM dbo.Stations;
DBCC CHECKIDENT ('dbo.Stations', RESEED, 0);

INSERT INTO dbo.Stations (Name, NameEn, ZoneNumber, LineCode) VALUES
    (N'Bến Thành',          'Ben Thanh',           1, 'MRT1'),
    (N'Nhà hát TP',         'City Opera House',     1, 'MRT1'),
    (N'Ba Son',              'Ba Son',               1, 'MRT1'),
    (N'Văn Thánh Bắc',      'Van Thanh North',      2, 'MRT1'),
    (N'Tân Cảng',            'Tan Cang',             2, 'MRT1'),
    (N'Thảo Điền',          'Thao Dien',            2, 'MRT1'),
    (N'An Phú',              'An Phu',               2, 'MRT1'),
    (N'Rạch Chiếc',         'Rach Chiec',           3, 'MRT1'),
    (N'Phước Long',         'Phuoc Long',           3, 'MRT1'),
    (N'Bình Thái',           'Binh Thai',            3, 'MRT1'),
    (N'Thủ Đức',            'Thu Duc',              3, 'MRT1'),
    (N'Khu CNC',             'Hi-Tech Park',         4, 'MRT1'),
    (N'Đại học Quốc gia',   'VNU',                  4, 'MRT1'),
    (N'Bến xe Miền Đông',   'Eastern Bus Terminal', 4, 'MRT1');
GO

-- ── Seed: FareRules ───────────────────────────────────────────────────────────
DELETE FROM dbo.FareRules;
DBCC CHECKIDENT ('dbo.FareRules', RESEED, 0);

INSERT INTO dbo.FareRules (FromZone, ToZone, Fare) VALUES
    (1, 1,  6000),
    (1, 2,  8000),
    (1, 3, 12000),
    (1, 4, 20000),
    (2, 2,  6000),
    (2, 3,  8000),
    (2, 4, 12000),
    (3, 3,  6000),
    (3, 4,  8000),
    (4, 4,  6000);
GO

-- ── Seed: Demo TransactionLogs ────────────────────────────────────────────────
INSERT INTO dbo.TransactionLogs (TicketId, Amount, PaymentMethod, [Status], [Timestamp], MachineId) VALUES
    ('TKT-20250406-0001',  8000, 'MoMo',       'Paid', DATEADD(HOUR,-3,GETDATE()), 'TVM-BT-001'),
    ('TKT-20250406-0002', 12000, 'VNPay',      'Paid', DATEADD(HOUR,-2,GETDATE()), 'TVM-BT-001'),
    ('TKT-20250406-0003',  6000, 'CreditCard', 'Paid', DATEADD(HOUR,-1,GETDATE()), 'TVM-BT-001'),
    ('TKT-20250406-0004', 20000, 'ZaloPay',    'Paid', DATEADD(MINUTE,-30,GETDATE()), 'TVM-BT-001');
GO

PRINT 'Database setup complete.';
GO
