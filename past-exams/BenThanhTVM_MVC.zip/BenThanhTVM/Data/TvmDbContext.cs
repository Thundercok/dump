using Microsoft.EntityFrameworkCore;
using BenThanhTVM.Models;

namespace BenThanhTVM.Data
{
    public class TvmDbContext : DbContext
    {
        public TvmDbContext(DbContextOptions<TvmDbContext> options) : base(options) { }

        public DbSet<Station> Stations => Set<Station>();
        public DbSet<FareRule> FareRules => Set<FareRule>();
        public DbSet<Ticket> Tickets => Set<Ticket>();
        public DbSet<TransactionLog> TransactionLogs => Set<TransactionLog>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Seed Stations (Ben Thanh Metro Line 1)
            modelBuilder.Entity<Station>().HasData(
                new Station { Id = 1,  Name = "Bến Thành",         NameEn = "Ben Thanh",         ZoneNumber = 1, LineCode = "MRT1" },
                new Station { Id = 2,  Name = "Nhà hát TP",        NameEn = "City Opera House",   ZoneNumber = 1, LineCode = "MRT1" },
                new Station { Id = 3,  Name = "Ba Son",             NameEn = "Ba Son",             ZoneNumber = 1, LineCode = "MRT1" },
                new Station { Id = 4,  Name = "Văn Thánh Bắc",     NameEn = "Van Thanh North",    ZoneNumber = 2, LineCode = "MRT1" },
                new Station { Id = 5,  Name = "Tân Cảng",           NameEn = "Tan Cang",           ZoneNumber = 2, LineCode = "MRT1" },
                new Station { Id = 6,  Name = "Thảo Điền",         NameEn = "Thao Dien",          ZoneNumber = 2, LineCode = "MRT1" },
                new Station { Id = 7,  Name = "An Phú",             NameEn = "An Phu",             ZoneNumber = 2, LineCode = "MRT1" },
                new Station { Id = 8,  Name = "Rạch Chiếc",        NameEn = "Rach Chiec",         ZoneNumber = 3, LineCode = "MRT1" },
                new Station { Id = 9,  Name = "Phước Long",        NameEn = "Phuoc Long",         ZoneNumber = 3, LineCode = "MRT1" },
                new Station { Id = 10, Name = "Bình Thái",          NameEn = "Binh Thai",          ZoneNumber = 3, LineCode = "MRT1" },
                new Station { Id = 11, Name = "Thủ Đức",           NameEn = "Thu Duc",            ZoneNumber = 3, LineCode = "MRT1" },
                new Station { Id = 12, Name = "Khu CNC",            NameEn = "Hi-Tech Park",       ZoneNumber = 4, LineCode = "MRT1" },
                new Station { Id = 13, Name = "Đại học Quốc gia",  NameEn = "VNU",                ZoneNumber = 4, LineCode = "MRT1" },
                new Station { Id = 14, Name = "Bến xe Miền Đông",  NameEn = "Eastern Bus Terminal",ZoneNumber = 4, LineCode = "MRT1" }
            );

            // Seed Fare Rules (Zone-based)
            modelBuilder.Entity<FareRule>().HasData(
                new FareRule { Id = 1,  FromZone = 1, ToZone = 1, Fare = 6000 },
                new FareRule { Id = 2,  FromZone = 1, ToZone = 2, Fare = 8000 },
                new FareRule { Id = 3,  FromZone = 1, ToZone = 3, Fare = 12000 },
                new FareRule { Id = 4,  FromZone = 1, ToZone = 4, Fare = 20000 },
                new FareRule { Id = 5,  FromZone = 2, ToZone = 2, Fare = 6000 },
                new FareRule { Id = 6,  FromZone = 2, ToZone = 3, Fare = 8000 },
                new FareRule { Id = 7,  FromZone = 2, ToZone = 4, Fare = 12000 },
                new FareRule { Id = 8,  FromZone = 3, ToZone = 3, Fare = 6000 },
                new FareRule { Id = 9,  FromZone = 3, ToZone = 4, Fare = 8000 },
                new FareRule { Id = 10, FromZone = 4, ToZone = 4, Fare = 6000 }
            );

            // Seed demo transaction logs
            modelBuilder.Entity<TransactionLog>().HasData(
                new TransactionLog { Id = 1, TicketId = "TKT-20250406-0001", Amount = 8000, PaymentMethod = "MoMo",       Status = "Paid", Timestamp = DateTime.Now.AddHours(-3), MachineId = "TVM-BT-001" },
                new TransactionLog { Id = 2, TicketId = "TKT-20250406-0002", Amount = 12000,PaymentMethod = "VNPay",      Status = "Paid", Timestamp = DateTime.Now.AddHours(-2), MachineId = "TVM-BT-001" },
                new TransactionLog { Id = 3, TicketId = "TKT-20250406-0003", Amount = 6000, PaymentMethod = "CreditCard", Status = "Paid", Timestamp = DateTime.Now.AddHours(-1), MachineId = "TVM-BT-001" },
                new TransactionLog { Id = 4, TicketId = "TKT-20250406-0004", Amount = 20000,PaymentMethod = "ZaloPay",    Status = "Paid", Timestamp = DateTime.Now.AddMinutes(-30), MachineId = "TVM-BT-001" }
            );
        }
    }
}
